from django.contrib import admin
from .models import Blog_Vlog_Post

admin.site.register(Blog_Vlog_Post)


